package com.problemstatement6.one;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentName {

	public static void main(String[] args) {

		ArrayList<String> alist = new ArrayList<String>();
		int n;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of Student : ");
		n = sc.nextInt();
		
		System.out.println("Enter the name of the Student : ");
		for (int i = 0; i < n; i++) {
			alist.add(sc.next());
		}
		
		System.out.println("Student list :");
		for (String a : alist) {
			System.out.println(a);
		}
		
		System.out.println(" Enter the name of student to be searched : ");
		String str = sc.next();
		
		int position = Collections.binarySearch(alist, str);
		
		if(position >= 0) {
			System.out.println(" Position of " + str + " is : " + position);			
		}else {
			System.out.println(" This student name is not present in this partrucular list.");
		}

	}

}
