package com.problemstatement1;

import java.util.Scanner;

public class TestRectangle {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		//1st Rectangle Object
		Rectangle rectr= new Rectangle();
		System.out.println("Enter length and breadth for Rectangle One: ");
		rectr.length=sc.nextInt();
		rectr.breadth=sc.nextInt();
		rectr.printData();
		System.out.println("Area of rectangle one: "+ rectr.printArea());
		
		//2nd Rectangle Object
		Rectangle rectr1= new Rectangle();
		System.out.println("Enter length and breadth for Rectangle Two: ");
		rectr1.length=sc.nextInt();
		rectr1.breadth=sc.nextInt();
		rectr1.printData();
		System.out.println("Area of rectangle two: "+ rectr1.printArea());
		
		//3rd Rectangle Object
		Rectangle rectr2= new Rectangle();
		System.out.println("Enter length and breadth for Rectangle Three: ");
		rectr2.length=sc.nextInt();
		rectr2.breadth=sc.nextInt();
		rectr2.printData();
		System.out.println("Area of rectangle three: "+ rectr2.printArea());
		
		//4th Rectangle Object
		Rectangle rectr3= new Rectangle();
		System.out.println("Enter length and breadth for Rectangle Four: ");
		rectr3.length=sc.nextInt();
		rectr3.breadth=sc.nextInt();
		rectr3.printData();
		System.out.println("Area of rectangle four: "+ rectr3.printArea());
		
		//5th Rectangle Object
		Rectangle rectr4= new Rectangle();
		System.out.println("Enter length and breadth for Rectangle Five: ");
		rectr4.length=sc.nextInt();
		rectr4.breadth=sc.nextInt();
		rectr4.printData();
		System.out.println("Area of rectangle five: "+ rectr4.printArea());
		
	}

}
