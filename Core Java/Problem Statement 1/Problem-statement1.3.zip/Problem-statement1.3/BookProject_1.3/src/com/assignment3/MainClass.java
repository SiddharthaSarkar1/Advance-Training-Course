package com.assignment3;

public class MainClass {
	
	Book bk[] = new Book[2];

	public void createBooks() {
		bk[0] = new Book("Java Programing ", 350.50);
		bk[1] = new Book("Let Us C", 200.00);
	}

	public void showBooks() {
		for (int i = 0; i < bk.length; i++) {
			bk[i].display();
			System.out.println(" ");
		}
	}

	public static void main(String[] args) {
		
		MainClass mc = new MainClass();
		mc.createBooks();
		mc.showBooks();

	}

}
