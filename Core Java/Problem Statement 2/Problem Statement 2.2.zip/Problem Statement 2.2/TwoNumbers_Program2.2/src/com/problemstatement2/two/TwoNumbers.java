package com.problemstatement2.two;

import java.util.Scanner;

public class TwoNumbers {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int num1, num2;
		System.out.println("Enter the first number : ");
		num1 = sc.nextInt();
		System.out.println("Enter the second number : ");
		num2 = sc.nextInt();

		System.out.println("First number is : " + num1);
		System.out.println("Second number is : " + num2);

		int n = 13;
		int firstTerm = num1;
		int secondTerm = num2;

		for (int i = 1; i <= n; i++) {
			System.out.print(firstTerm + " ");

			int nextTerm = firstTerm + secondTerm;
			firstTerm = secondTerm;
			secondTerm = nextTerm;
		}

	}

}
