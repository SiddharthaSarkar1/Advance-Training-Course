package com.problemstatement3.one;

public abstract class Instrument {

	public abstract void Play();
	
}
